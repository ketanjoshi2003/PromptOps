import React, { useState, useEffect } from 'react';
import styles from './Layout.module.css';
import { FiHome, FiMessageSquare, FiFolder, FiSettings, FiLayers } from 'react-icons/fi';

const Layout = ({ children, onPromptSelect, currentView, onNavigate }) => {
    // Initialize based on screen width
    const [isSidebarOpen, setIsSidebarOpen] = useState(typeof window !== 'undefined' ? window.innerWidth > 768 : true);

    // Auth State
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isAuthOpen, setIsAuthOpen] = useState(false);
    const [authMode, setAuthMode] = useState('login'); // 'login' | 'register'
    const [isLoading, setIsLoading] = useState(false);

    // Auto-close on resize to mobile
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth <= 768) {
                setIsSidebarOpen(false);
            } else {
                setIsSidebarOpen(true);
            }
        };
        // Simple initial check logic preserved
    }, []);

    const handleAuthClick = () => {
        if (isAuthenticated) {
            if (window.confirm("Are you sure you want to sign out?")) {
                setIsAuthenticated(false);
            }
        } else {
            setAuthMode('login');
            setIsAuthOpen(true);
        }
    };

    const handleAuthSubmit = () => {
        setIsLoading(true);
        // Simulate network request
        setTimeout(() => {
            setIsLoading(false);
            setIsAuthenticated(true);
            setIsAuthOpen(false);
        }, 1500);
    };

    return (
        <div className={styles.container}>
            {/* Mobile Overlay Backdrop */}
            <div
                className={`${styles.overlay} ${isSidebarOpen ? styles.overlayOpen : ''}`}
                onClick={() => setIsSidebarOpen(false)}
            />

            <aside className={`${styles.sidebar} ${isSidebarOpen ? styles.sidebarOpen : styles.sidebarClosed}`}>

                <div className={styles.sidebarNav}>
                    <button
                        className={`${styles.navItem} ${currentView === 'dashboard' ? styles.navItemActive : ''}`}
                        onClick={() => {
                            onNavigate('dashboard');
                            if (window.innerWidth <= 768) setIsSidebarOpen(false);
                        }}
                    >
                        <FiHome />
                        Home
                    </button>
                    <button
                        className={`${styles.navItem} ${currentView === 'chain' ? styles.navItemActive : ''}`}
                        onClick={() => {
                            onNavigate('chain');
                            if (window.innerWidth <= 768) setIsSidebarOpen(false);
                        }}
                    >
                        <FiLayers />
                        Chain
                    </button>
                    <button
                        className={`${styles.navItem} ${currentView === 'chat' ? styles.navItemActive : ''}`}
                        onClick={() => {
                            onNavigate('chat');
                            if (window.innerWidth <= 768) setIsSidebarOpen(false);
                        }}
                    >
                        <FiMessageSquare />
                        Chat
                    </button>
                    <button
                        className={`${styles.navItem} ${currentView === 'projects' ? styles.navItemActive : ''}`}
                        onClick={() => {
                            onNavigate('projects');
                            if (window.innerWidth <= 768) setIsSidebarOpen(false);
                        }}
                    >
                        <FiFolder />
                        Projects
                    </button>

                </div>

                <div className={styles.bottomNav}>
                    <button
                        className={`${styles.navItem} ${currentView === 'settings' ? styles.navItemActive : ''}`}
                        onClick={() => {
                            onNavigate('settings');
                            if (window.innerWidth <= 768) setIsSidebarOpen(false);
                        }}
                    >
                        <FiSettings />
                        Settings
                    </button>
                </div>

                <div className={styles.userProfile} onClick={handleAuthClick}>
                    <div className={styles.avatar}>
                        {isAuthenticated ? 'U' : '?'}
                    </div>
                    <div className={styles.userInfo}>
                        <div className={styles.username}>
                            {isAuthenticated ? 'User' : 'Sign In'}
                        </div>
                    </div>
                </div>
            </aside>
            <main className={styles.main}>
                <div className={styles.topBar}>
                    <button
                        className={styles.menuBtn}
                        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                        aria-label="Toggle Menu"
                    >
                        ☰
                    </button>
                    <div className={styles.logoMark}>
                        <div className={styles.redCircle}>
                            <span className={styles.pipe}>|</span>
                        </div>
                    </div>
                    <span className={styles.modelName}>PromptOps</span>
                </div>
                <div className={styles.contentArea}>
                    {children}
                </div>
            </main>

            {/* Auth Modal */}
            {isAuthOpen && (
                <div className={styles.modalOverlay} onClick={() => setIsAuthOpen(false)}>
                    <div className={styles.loginModal} onClick={e => e.stopPropagation()}>
                        <h2 className={styles.modalTitle}>
                            {authMode === 'login' ? 'Welcome Back' : 'Create Account'}
                        </h2>
                        <p className={styles.modalSubtitle}>
                            {authMode === 'login'
                                ? 'Enter your details to access your workspace.'
                                : 'Join us to start building better prompts.'}
                        </p>

                        <div key={authMode} className={styles.formFade}>
                            {authMode === 'register' && (
                                <div className={styles.inputGroup}>
                                    <input
                                        type="text"
                                        placeholder="Full Name"
                                        className={styles.loginInput}
                                        autoFocus
                                    />
                                </div>
                            )}

                            <div className={styles.inputGroup}>
                                <input
                                    type="email"
                                    placeholder="Email Address"
                                    className={styles.loginInput}
                                />
                            </div>

                            <div className={styles.inputGroup}>
                                <input
                                    type="password"
                                    placeholder="Password"
                                    className={styles.loginInput}
                                />
                            </div>

                            <button
                                className={styles.loginBtn}
                                onClick={handleAuthSubmit}
                                disabled={isLoading}
                            >
                                {isLoading ? 'Processing...' : (authMode === 'login' ? 'Sign In' : 'Create Account')}
                            </button>
                        </div>

                        <div className={styles.authSwitch}>
                            {authMode === 'login' ? (
                                <>
                                    Don't have an account?{' '}
                                    <span onClick={() => setAuthMode('register')}>Sign up</span>
                                </>
                            ) : (
                                <>
                                    Already have an account?{' '}
                                    <span onClick={() => setAuthMode('login')}>Sign in</span>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Layout;
