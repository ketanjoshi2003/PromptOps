import React from 'react';
import Layout from './components/Layout/Layout';
import Dashboard from './pages/Dashboard/Dashboard';
import Projects from './pages/Projects/Projects';
import ChatPage from './pages/ChatPage';
import SettingsPage from './pages/SettingsPage';


import ChainPage from './pages/ChainPage';

const App = () => {
  const [autoPrompt, setAutoPrompt] = React.useState(null);

  // Initialize from localStorage or default to 'dashboard'
  const [currentView, setCurrentView] = React.useState(() => {
    return localStorage.getItem('currentView') || 'dashboard';
  });

  // Initialize theme from localStorage or default to 'dark'
  const [theme, setTheme] = React.useState(() => {
    return localStorage.getItem('theme') || 'dark';
  });

  // Save to localStorage whenever view changes
  React.useEffect(() => {
    localStorage.setItem('currentView', currentView);
  }, [currentView]);

  // Apply theme to document
  React.useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  return (
    <Layout
      onPromptSelect={setAutoPrompt}
      currentView={currentView}
      onNavigate={setCurrentView}
    >
      <div style={{ display: currentView === 'dashboard' ? 'block' : 'none', height: '100%' }}>
        <Dashboard
          autoPrompt={autoPrompt}
          onPromptHandled={() => setAutoPrompt(null)}
        />
      </div>
      <div style={{ display: currentView === 'chain' ? 'block' : 'none', height: '100%' }}>
        <ChainPage />
      </div>
      <div style={{ display: currentView === 'chat' ? 'block' : 'none', height: '100%' }}>
        <ChatPage />
      </div>
      <div style={{ display: currentView === 'projects' ? 'block' : 'none', height: '100%' }}>
        <Projects isVisible={currentView === 'projects'} />
      </div>
      <div style={{ display: currentView === 'settings' ? 'block' : 'none', height: '100%' }}>
        <SettingsPage theme={theme} setTheme={setTheme} />
      </div>
    </Layout>
  );
};

export default App;
