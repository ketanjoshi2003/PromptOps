import React, { useState, useEffect } from 'react';
import styles from './Projects.module.css';
import { FiSearch, FiTrash2, FiX, FiCheckSquare, FiSquare, FiList } from 'react-icons/fi';

const Projects = ({ isVisible }) => {
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);
    const [expandedIds, setExpandedIds] = useState(new Set());
    const [copiedId, setCopiedId] = useState(null);
    const [editingId, setEditingId] = useState(null);
    const [editForm, setEditForm] = useState({ title: '', content: '' });
    const [searchQuery, setSearchQuery] = useState('');

    // Bulk Selection State
    const [isSelectionMode, setIsSelectionMode] = useState(false);
    const [selectedIds, setSelectedIds] = useState(new Set());

    const textareaRef = React.useRef(null);

    // Auto-resize textarea when content changes or editing starts
    useEffect(() => {
        if (editingId && textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
        }
    }, [editingId, editForm.content]);

    const fetchProjects = async () => {
        try {
            const response = await fetch('http://localhost:8000/api/projects');
            if (response.ok) {
                const data = await response.json();
                setProjects(data);
            }
        } catch (error) {
            console.error("Failed to fetch projects:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (!isVisible) return;

        const fetchProjects = async () => {
            setLoading(true);
            try {
                const response = await fetch('http://localhost:8000/api/projects');
                if (response.ok) {
                    const data = await response.json();
                    setProjects(data);
                }
            } catch (error) {
                console.error("Failed to fetch projects:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchProjects();
    }, [isVisible]);

    const toggleProject = (id) => {
        const newExpanded = new Set(expandedIds);
        if (newExpanded.has(id)) {
            newExpanded.delete(id);
        } else {
            newExpanded.add(id);
        }
        setExpandedIds(newExpanded);
    };

    const deleteProject = async (e, id) => {
        e.stopPropagation();
        if (!window.confirm("Are you sure you want to delete this project?")) return;

        try {
            const response = await fetch(`http://localhost:8000/api/projects/${id}`, {
                method: 'DELETE',
            });
            if (response.ok) {
                setProjects(prev => prev.filter(p => p.id !== id));
            }
        } catch (error) {
            console.error("Failed to delete project:", error);
        }
    };

    const handleCopy = (e, content, id) => {
        e.stopPropagation();
        navigator.clipboard.writeText(content);
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2000);
    };

    const handleEdit = (e, project) => {
        e.stopPropagation();
        setEditingId(project.id);
        setEditForm({ title: project.title, content: project.content });
        // Expand the project when editing
        setExpandedIds(prev => new Set(prev).add(project.id));
    };

    const handleCancelEdit = (e) => {
        e.stopPropagation();
        setEditingId(null);
        setEditForm({ title: '', content: '' });
    };

    const handleSaveEdit = async (e, id) => {
        e.stopPropagation();
        try {
            const response = await fetch(`http://localhost:8000/api/projects/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(editForm),
            });

            if (response.ok) {
                setProjects(prev => prev.map(p =>
                    p.id === id ? { ...p, title: editForm.title, content: editForm.content } : p
                ));
                setEditingId(null);
            }
        } catch (error) {
            console.error("Failed to update project:", error);
        }
    };

    const filteredProjects = projects.filter(project =>
        project.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    // Bulk Actions handler
    const toggleSelectionMode = () => {
        setIsSelectionMode(!isSelectionMode);
        setSelectedIds(new Set());
    };

    const toggleProjectSelection = (e, id) => {
        e.stopPropagation();
        const newSelected = new Set(selectedIds);
        if (newSelected.has(id)) {
            newSelected.delete(id);
        } else {
            newSelected.add(id);
        }
        setSelectedIds(newSelected);
    };

    const toggleSelectAll = () => {
        if (selectedIds.size === filteredProjects.length && filteredProjects.length > 0) {
            setSelectedIds(new Set());
        } else {
            const allIds = new Set(filteredProjects.map(p => p.id));
            setSelectedIds(allIds);
        }
    };

    const handleBulkDelete = async () => {
        if (selectedIds.size === 0) return;
        if (!window.confirm(`Are you sure you want to delete ${selectedIds.size} projects?`)) return;

        try {
            const response = await fetch('http://localhost:8000/api/projects', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Array.from(selectedIds))
            });

            if (response.ok) {
                setProjects(prev => prev.filter(p => !selectedIds.has(p.id)));
                setSelectedIds(new Set());
                setIsSelectionMode(false);
            }
        } catch (error) {
            console.error("Failed to bulk delete:", error);
        }
    };

    if (loading) {
        return <div className={styles.container}>Loading projects...</div>;
    }

    return (
        <div className={styles.container}>
            <div className={styles.headerRow}>
                <h1 className={styles.title}>Projects</h1>
                <div className={styles.actions}>
                    {isSelectionMode ? (
                        <>
                            <button
                                className={`${styles.actionBtn} ${styles.deleteBtn} ${selectedIds.size === 0 ? styles.disabled : ''}`}
                                onClick={handleBulkDelete}
                                disabled={selectedIds.size === 0}
                            >
                                <FiTrash2 /> Delete ({selectedIds.size})
                            </button>
                            <button className={styles.actionBtn} onClick={toggleSelectAll}>
                                {selectedIds.size === filteredProjects.length && filteredProjects.length > 0 ? <FiCheckSquare /> : <FiSquare />} All
                            </button>
                            <button className={styles.actionBtn} onClick={toggleSelectionMode}>
                                <FiX /> Cancel
                            </button>
                        </>
                    ) : (
                        projects.length > 0 && (
                            <button className={styles.actionBtn} onClick={toggleSelectionMode}>
                                <FiList /> Select
                            </button>
                        )
                    )}
                </div>
            </div>

            {projects.length > 0 && (
                <div className={styles.searchContainer}>
                    <div className={styles.searchIcon}>
                        <FiSearch />
                    </div>
                    <input
                        type="text"
                        className={styles.searchInput}
                        placeholder="Search projects..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
            )}

            <div className={styles.projectList}>
                {filteredProjects.map((project) => (
                    <div
                        key={project.id}
                        className={`${styles.projectItem} ${expandedIds.has(project.id) ? styles.expanded : ''} ${selectedIds.has(project.id) ? styles.selected : ''}`}
                        onClick={isSelectionMode ? (e) => toggleProjectSelection(e, project.id) : undefined}
                    >
                        {isSelectionMode && (
                            <div className={styles.checkbox}>
                                {selectedIds.has(project.id) ? <FiCheckSquare /> : <FiSquare />}
                            </div>
                        )}

                        <div
                            className={styles.projectHeader}
                            onClick={(e) => {
                                if (isSelectionMode) toggleProjectSelection(e, project.id);
                                else if (!editingId) toggleProject(project.id);
                            }}
                        >
                            <div className={styles.titleWrapper}>

                                {editingId === project.id ? (
                                    <input
                                        type="text"
                                        className={styles.editTitleInput}
                                        value={editForm.title}
                                        onChange={(e) => setEditForm(prev => ({ ...prev, title: e.target.value }))}
                                        onClick={(e) => e.stopPropagation()}
                                    />
                                ) : (
                                    <span className={styles.projectTitle}>{project.title}</span>
                                )}
                            </div>
                            <div className={styles.metaInfo}>
                                {editingId === project.id ? (
                                    <>
                                        <button
                                            className={styles.iconButton}
                                            onClick={(e) => handleSaveEdit(e, project.id)}
                                            title="Save"
                                        >
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: '#4ade80' }}>
                                                <polyline points="20 6 9 17 4 12"></polyline>
                                            </svg>
                                        </button>
                                        <button
                                            className={styles.iconButton}
                                            onClick={handleCancelEdit}
                                            title="Cancel"
                                        >
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: '#f87171' }}>
                                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                                <line x1="6" y1="6" x2="18" y2="18"></line>
                                            </svg>
                                        </button>
                                    </>
                                ) : (
                                    <>
                                        <button
                                            className={styles.iconButton}
                                            onClick={(e) => handleEdit(e, project)}
                                            title="Edit Project"
                                        >
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                            </svg>
                                        </button>
                                        <button
                                            className={styles.iconButton}
                                            onClick={(e) => handleCopy(e, project.content, project.id)}
                                            title="Copy Content"
                                        >
                                            {copiedId === project.id ? (
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: '#4ade80' }}>
                                                    <polyline points="20 6 9 17 4 12"></polyline>
                                                </svg>
                                            ) : (
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                                                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                                                </svg>
                                            )}
                                        </button>
                                        <button
                                            className={styles.iconButton}
                                            onClick={(e) => deleteProject(e, project.id)}
                                            title="Delete Project"
                                        >
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                                <polyline points="3 6 5 6 21 6"></polyline>
                                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                            </svg>
                                        </button>
                                    </>
                                )}
                                <span className={styles.projectDate}>
                                    {new Date(project.created_at).toLocaleDateString()}
                                </span>
                            </div>
                        </div>
                        <div className={`${styles.contentWrapper} ${expandedIds.has(project.id) ? styles.contentOpen : ''}`}>
                            <div className={styles.projectContent}>
                                {editingId === project.id ? (
                                    <textarea
                                        ref={textareaRef}
                                        className={styles.editContentInput}
                                        value={editForm.content}
                                        onChange={(e) => setEditForm(prev => ({ ...prev, content: e.target.value }))}
                                        onClick={(e) => e.stopPropagation()}
                                    />
                                ) : (
                                    <pre className={styles.codeBlock}>
                                        {project.content}
                                    </pre>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
                {projects.length === 0 && (
                    <div style={{ color: 'var(--color-text-muted)' }}>
                        No projects found. Generate a prompt to get started!
                    </div>
                )}
            </div>
        </div>
    );
};

export default Projects;
