import React from 'react';
import styles from './SettingsPage.module.css';
import { FiMoon, FiSun } from 'react-icons/fi';

const SettingsPage = ({ theme, setTheme }) => {
    return (
        <div className={styles.container}>
            <h1 className={styles.title}>Settings</h1>

            <div className={styles.section}>
                <h2 className={styles.sectionTitle}>Appearance</h2>
                <div className={styles.settingItem}>
                    <div className={styles.settingInfo}>
                        <span className={styles.settingName}>Theme Mode</span>
                        <span className={styles.settingDescription}>
                            Select your preferred interface theme
                        </span>
                    </div>

                    <div className={styles.toggleContainer}>
                        <button
                            className={`${styles.themeBtn} ${theme === 'light' ? styles.active : ''}`}
                            onClick={() => setTheme('light')}
                        >
                            <FiSun /> Light
                        </button>
                        <button
                            className={`${styles.themeBtn} ${theme === 'dark' ? styles.active : ''}`}
                            onClick={() => setTheme('dark')}
                        >
                            <FiMoon /> Dark
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SettingsPage;
